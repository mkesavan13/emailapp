class route{
    constructor(routeInfo){
        this.routeInfo = routeInfo;
    }

    transition(){
        //apply transition
        if(typeof fk_fw.components[this.routeInfo.component] === "undefined"){
            fk_fw.loadJS(`components/${this.routeInfo.component}.js`);
        }
        let intervalElem;
        intervalElem = setInterval(() => {
            if(fk_fw.components[this.routeInfo.component]){
                fk_fw.renderComponent(fk_fw.components[this.routeInfo.component].render()); 
                clearInterval(intervalElem);
            }
        },0)
    }
}

let appRoutes = {
    "/": new route({
        "component":"home-comp"
    }),
    "/?": new route({
        "component": "email-comp",
        "hasQuery": true,
        query: ["id","filter"]
    })
}