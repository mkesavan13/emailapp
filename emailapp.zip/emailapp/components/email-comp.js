fk_fw.components["email-comp"] = {
    render(){
        return `
            <h1>Email Comp</h1>;
        `;
    }
}